import os
import json
import subprocess
import requests
from flask import send_from_directory, Flask, render_template, Response

app = Flask(__name__)

# Definice kanálů
CHANNELS = {
    "CH_1": "ČT 1",
    "CH_2": "ČT 2",
    "CH_4": "ČT Sport",
    "CH_5": "ČT Big Grin",
    "CH_6": "ČT Art",
    "CH_7": "ČT 3",
    "CH_24": "ČT 24",
    "CH_25": "CT iVysilani+ 1",
    "CH_26": "CT iVysilani+ 2",
    "CH_27": "CT iVysilani+ 3",
    "CH_28": "CT iVysilani+ 4",
    "CH_29": "CT iVysilani+ 5",
    "CH_30": "CT iVysilani+ 6",
    "CH_31": "CT iVysilani+ 7",
    "CH_32": "CT iVysilani+ 8",
    "CH_MOB_01": "CT iVysilani+ 9",
    "CH_MP_01": "CT iVysilani+ 10",
    "CH_MP_02": "CT iVysilani+ 11",
    "CH_MP_03": "CT iVysilani+ 12",
    "CH_MP_04": "CT iVysilani+ 13",
    "CH_MP_05": "CT iVysilani+ 14",
    "CH_MP_06": "CT iVysilani+ 15",
    "CH_MP_07": "CT iVysilani+ 16",
    "CH_MP_08": "CT iVysilani+ 17"
}

API_URL = "https://api.ceskatelevize.cz/video/v1/playlist-live/v1/stream-data/channel/{}?canPlayDrm=false&streamType=dash"


def get_stream_url(channel):
    """Získá streamovací URL pro daný kanál."""
    response = requests.get(API_URL.format(channel))
    if response.status_code == 200:
        data = response.json()
        return data.get("streamUrls", {}).get("main", None)
    return None


def stream_channel(channel):
    """Spustí FFmpeg a streamuje kanál."""
    stream_url = get_stream_url(channel)
    if not stream_url:
        return Response("Stream nenalezen", status=404)
    
    process = subprocess.Popen(
        ["ffmpeg", "-fflags", "+genpts", "-i", stream_url, "-f", "mpegts", "-c:v", "copy", "-c:a", "copy", "-metadata", f"service_provider=CT iVysilani", "-metadata", f"service_name={channel}", "pipe:1"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        bufsize=0
    )
    
    def generate():
        while True:
            chunk = process.stdout.read(1024)
            if not chunk:
                break
            yield chunk
    
    return Response(generate(), content_type="video/mp2t")


@app.route('/')
def index():
    """Hlavní stránka s výběrem kanálů."""
    return render_template("index.html", channels=CHANNELS)


@app.route('/stream/<channel>')
def stream(channel):
    """Streamuje vybraný kanál."""
    if channel in CHANNELS:
        return stream_channel(channel)
    return "Neplatný kanál", 404

@app.route('/logo/<filename>')
def logo(filename):
    return send_from_directory('static', filename)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5090, debug=True)
